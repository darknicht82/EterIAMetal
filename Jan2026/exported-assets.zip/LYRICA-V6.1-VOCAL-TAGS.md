# 🎤 LYRICA V6.1 - VOCAL TAGS & SUNO V5 PARAMETERS

## Master Reference for SUNO V5 Advanced Options

---

## 📋 SUNO V5 – PARÁMETROS POR SUBGÉNERO (LYRICA V6.1)

### 🎸 POWER METAL

**Sliders:**
- Weirdness: 12%
- Style Influence: 75%
- Audio Influence (si hay referencia): 35%

**Escenarios:**
- Generación normal (sin upload): W 12%, SI 75%
- Con referencia vocal (tenor): W 10%, SI 75%, AI 50%
- Extend: W 0%, SI 75%
- Replace Section: W 4%, SI 77%

**Vocal Tags Recomendados:**
```
[Anthemic], [Heroic], [Powerful], [Clear], [Confident]
[Tenor range], [Bright timbre], [Steady vibrato]
```

**Instrumentales:**
```
[Power metal guitar], [Dual lead], [Fast drums], [Prominent bass]
```

---

### 🖤 DOOM METAL

**Sliders:**
- Weirdness: 45%
- Style Influence: 72%
- Audio Influence: 50%

**Escenarios:**
- Generación normal: W 45%, SI 72%
- Con referencia barítono/growl: W 43%, SI 72%, AI 50–55%
- Extend: W 33%, SI 72%
- Replace Section: W 37%, SI 74%

**Vocal Tags Recomendados:**
```
[Dark], [Resonant], [Deep], [Mournful], [Heavy]
[Baritone range], [Slow vibrato], [Breathy tone]
[Growl-capable], [Sustained delivery]
```

**Instrumentales:**
```
[Doom riff], [Slow drums], [Thick bass], [Organ pads]
```

---

### ✨ SYMPHONIC METAL

**Sliders:**
- Weirdness: 28%
- Style Influence: 75%
- Audio Influence: 40%

**Escenarios:**
- Generación normal: W 28%, SI 75%
- Con referencia orquestal/soprano: W 30%, SI 75%, AI 40%
- Extend: W 16%, SI 75%
- Replace Section: W 20%, SI 77%

**Vocal Tags Recomendados:**
```
[Operatic], [Ethereal], [Soaring], [Ornamental], [Epic]
[Soprano-Mezzo range], [Vibrato rich], [Clean articulation]
[Theatrical], [Emotional nuance]
```

**Instrumentales:**
```
[Orchestral strings], [Synth pads], [Choir], [Metal riff foundation]
```

---

### 🌑 GOTHIC METAL

**Sliders:**
- Weirdness: 33%
- Style Influence: 76%
- Audio Influence: 45%

**Escenarios:**
- Generación normal: W 33%, SI 76%
- Con referencia vocal íntima: W 31%, SI 76%, AI 45–50%
- Extend: W 21%, SI 76%
- Replace Section: W 25%, SI 78%

**Vocal Tags Recomendados:**
```
[Vulnerable], [Intimate], [Melancholic], [Breathy], [Nostalgic]
[Mezzo-Soprano range], [Controlled vibrato], [Raw emotion]
[Whisper-capable], [Tender delivery]
```

**Instrumentales:**
```
[Gothic organ], [Atmospheric synth], [Gentle cello], [Dark guitar]
```

---

### 🔥 METALCORE (CRITICAL FIX)

**Sliders:**
- Weirdness: 52%
- Style Influence: 70%
- Audio Influence: 55%

**⚠️ CRÍTICO: Weirdness 52% (not 60%)**
- V6 legacy 60% causaba drift en Extend
- V6.1 reduce a 52% para evitar style shift

**Escenarios:**
- Generación normal: W 52%, SI 70%
- Con referencia scream/shout: W 50%, SI 70%, AI 55–60%
- Extend: W 40%, SI 70% ← Reduce 12% (CRITICAL)
- Replace Section: W 44%, SI 72%

**Vocal Tags Recomendados:**
```
[Aggressive], [Raw], [Intense], [Powerful], [Dynamic]
[Tenor-Baritone], [Attack-heavy], [Scream-capable]
[Transition smooth/aggressive], [Double tracking potential]
```

**Instrumentales:**
```
[Breakdowns], [Double bass drums], [Chugga riff], [Synth drops]
```

---

### 🍻 FOLK METAL

**Sliders:**
- Weirdness: 35%
- Style Influence: 76%
- Audio Influence: 35%

**Escenarios:**
- Generación normal: W 35%, SI 76%
- Con referencia folk (instrumental/coros): W 37%, SI 76%, AI 35–40%
- Extend: W 23%, SI 76%
- Replace Section: W 27%, SI 78%

**Vocal Tags Recomendados:**
```
[Tribal], [Celebratory], [Earthy], [Groovy], [Community]
[Warm tone], [Chant-capable], [Rhythmic delivery]
[Natural vibrato], [Ensemble-ready]
```

**Instrumentales:**
```
[Folk instruments], [Accordion], [Pipes], [Tribal drums], [Metal guitars]
```

---

### 🎼 NEOCLASSICAL METAL (CRITICAL FIX)

**Sliders:**
- Weirdness: 18%
- Style Influence: 78%
- Audio Influence: 60%

**⚠️ CRÍTICO: Style Influence 78% (not 90%)**
- V6 legacy 90% causaba vocals robóticos sin fraseo
- V6.1 reduce a 78% (aún debajo plateau 80%) para elegancia técnica

**Escenarios:**
- Generación normal: W 18%, SI 78%
- Con referencia guitarra/teclado clásico: W 20%, SI 78%, AI 60–65%
- Extend: W 6%, SI 78%
- Replace Section: W 10%, SI 80%

**Vocal Tags Recomendados:**
```
[Virtuoso], [Technical], [Precise], [Classical], [Elegant]
[Tenor-Soprano], [Vibrato controlled], [Clarity supreme]
[Bach-influenced phrasing], [Note-perfect delivery]
```

**Instrumentales:**
```
[Classical guitar], [Synth keyboard], [String quartet foundation]
[Metal distortion layer], [Harpsichord ambience]
```

---

## 🎛️ REGLAS GLOBALES SLIDERS – LYRICA V6.1

### 1. Style Influence (SI)

**Regla principal:**
- **NO usar > 80%** (SUNO V5 Feb 2026: "Above 80%, plateau occurs + reduced vocal phrasing variation")
- Rango LYRICA recomendado: **70%–78% según subgénero**
- SI más alta → género más estricto, pero menos variación en fraseo vocal

**Impact:**
- SI 75% = good balance between genre clarity and vocal freedom
- SI 80%+ = vocals sound locked-in, robotic, no breathing space
- SI < 70% = genre character weakens

---

### 2. Weirdness (W)

**Definición:**
- Controla predictability vs experimental deviation
- Neutro ~50%. LYRICA usa valores más bajos para metal épico estructurado

**Base values por acción:**
- **Generación normal:** usar W de tabla
- **Extend:** usar W_base − 12% (CRITICAL: previene style drift)
- **Replace Section:** usar W_base − 8% (mantiene coherencia)
- **Con referencia vocal:** usar W_base − 2% (preserva Persona)
- **Con referencia instrumental:** usar W_base + 3% (permite elaboración)

**Impact:**
- W más alto = más variación, riesgo de incoherencia
- W más bajo = más predecible, menos sorpresas
- Extend con W alto = drift completo de estilo (AVOID)

---

### 3. Audio Influence (AI)

**Aplicación:**
- Solo aplica cuando hay **upload de audio** (voz o instrumental)
- SUNO V5 new feature - missing en V6

**Configuración por tipo:**
- **Referencia vocal (lead):** 45–60% (tu voz/referencia domina carácter)
- **Referencia instrumental:** 35–50% (guía pero no encadena)
- **Referencia subtle/texture:** 20–30% (casi ambience)

**Rules:**
- AI muy bajo (< 30%) = referencia casi no influye, pura sugestión
- AI mediano (35–50%) = referencia guía + AI agrega contexto
- AI alto (55–65%) = referencia domina tone/phrasing, AI respeta eso
- Nunca > 75% (suena calcado, pierde creatividad V5)

---

## 🎯 ESCENARIOS RÁPIDOS

### Escenario 1: Generación Normal (Solo Texto)

```
Usar W y SI de tabla por subgénero
Audio Influence: OFF (no hay upload)

Ejemplo Power Metal:
- Weirdness: 12%
- Style Influence: 75%
- Audio Influence: N/A
```

### Escenario 2: Con Referencia Vocal (Tu voz grabada)

```
Reducir W −2%, mantener SI, usar AI según tabla

Ejemplo Power Metal con tenor reference:
- Weirdness: 10% (12% − 2%)
- Style Influence: 75% (normal)
- Audio Influence: 50% (strong anchor)

Resultado: V5 aprende tu timbre, aplica a full track
```

### Escenario 3: Con Referencia Instrumental (Guitar/Synth loop)

```
Aumentar W +3%, mantener SI, usar AI según tabla

Ejemplo Symphonic con strings reference:
- Weirdness: 31% (28% + 3%)
- Style Influence: 75% (normal)
- Audio Influence: 40% (moderate guide)

Resultado: V5 amplifica la textura, no copia exacto
```

### Escenario 4: EXTEND (Alargar sección existente)

```
Reducir W −12%, mantener SI, sin AI

Ejemplo Metalcore Extend:
- Weirdness: 40% (52% − 12%) ← CRITICAL
- Style Influence: 70% (normal)
- Audio Influence: OFF

Resultado: Continuación suave, sin style drift
```

### Escenario 5: REPLACE SECTION (Regenerar slice mid-track)

```
Reducir W −8%, aumentar SI +2%, sin AI

Ejemplo Gothic Replace Bridge:
- Weirdness: 25% (33% − 8%)
- Style Influence: 78% (76% + 2%)
- Audio Influence: OFF

Resultado: Nueva sección cohesiva con track existente
```

---

## 🚫 EXCLUDE STYLES – V6.1 ENHANCED

**Total: 37 items (was 30 in V6)**

Copy entire list to SUNO V5 "Exclude Styles" field:

```
harsh digital artifacts, clipping, bright highs, digital clicking,
square wave artifacts, harsh treble, rough transients, metallic tone,
thin production, amateur quality, synthetic tone, robotic vocals,
digital harshness, white noise, shimmer, residual noise, latent artifacts,
muddy mix, poor separation, compressed sound, flat dynamics,
poor voice leading, muddled harmonies, unclear chord progression,
forced vibrato, unnatural breathiness, inconsistent tone, vocal strain
artifacts, autotune artifacts, amateur mastering, insufficient stereo
separation, phase issues in mix, Spanish Spain accent, Castilian
pronunciation, theta sound, Spanish lisp pronunciation, European Spanish,
Spain dialect, European accent
```

---

## 🎤 PERSONAS CONSISTENCY PROTOCOL

### After Generation: Save Vocal as Persona

**Step 1: Evaluate Generated Vocal**
```
✓ Does vocal match [Vocal Tag] definitions?
✓ Is vibrato/breathiness appropriate for subgénero?
✓ Does tone character match intended emotion?

IF YES → Proceed to save
IF NO → Regenerate with adjusted sliders
```

**Step 2: Save as Persona in SUNO Studio**
```
1. Click track → [Menu] → "Save as Persona"
2. Naming convention: [SUBGÉNERO]_[PROJECT]_[CHARACTER]
   Examples:
   - POWER_ETERIA_HEROIC_TENOR
   - DOOM_ETERIA_BARITONE_DARK
   - SYMPHONIC_ETERIA_SOPRANO_EPIC
   - GOTHIC_ETERIA_VULNERABLE_INTIMATE
   - METALCORE_ETERIA_AGGRESSIVE_TENOR
   - FOLK_ETERIA_TRIBAL_POTENT
   - NEOCLASSICAL_ETERIA_VIRTUOSO_TECHNICAL
```

**Step 3: Use Locked Persona for Future Sections**
```
Before generating next section (Bridge, Final Chorus, etc.):
1. Select [Locked Persona] from dropdown
2. Adjust sliders:
   - Weirdness: [Table value] − 2%  ← preserve consistency
   - Style Influence: [Table value]
   - Audio Influence: OFF
3. Generate

Result: Same vocalist across entire track ✓
```

---

## 🎼 TIMING FLEXIBLE WINDOWS (V6.1)

### Instead of Rigid Seconds, Use Ranges

**POWER METAL (4:30 target)**

- Intro: 25–30s
- Verse 1: 38–42s
- Pre-Chorus: 16–20s
- Chorus: 33–37s
- Verse 2: 38–42s
- Bridge: 26–30s
- Guitar Solo: 28–32s
- Final Chorus: 38–42s
- Outro: 12–14s

**Total tolerance: ±8s from 270s meta**

---

### DOOM METAL (5:30 target)

- Intro: 30–35s
- Verse 1: 45–50s
- Pre-Chorus: 18–25s
- Chorus: 40–45s
- Verse 2: 45–50s
- Bridge (emotional): 30–40s (flex for impact)
- Solo: 35–40s
- Final Chorus: 45–50s
- Outro: 15–20s

**Total tolerance: ±10s from 330s meta**

---

### SYMPHONIC METAL (4:30 target)

- Intro: 28–35s (orchestral build)
- Verse 1: 40–45s
- Pre-Chorus: 20–25s
- Chorus: 35–40s (anthemic)
- Verse 2: 40–45s
- Bridge: 28–35s (emotional shift)
- Orchestra Swell: 20–25s
- Final Chorus: 40–45s
- Outro: 12–18s

**Total tolerance: ±8s from 270s meta**

---

### GOTHIC METAL (4:15 target)

- Intro: 22–28s (intimate)
- Verse 1: 35–40s
- Pre-Chorus: 15–20s
- Chorus: 30–35s (builds slowly)
- Verse 2: 35–40s
- Bridge: 25–32s (vulnerable apex)
- Clean Section: 18–22s
- Final Chorus: 35–40s
- Outro: 12–16s

**Total tolerance: ±6s from 255s meta**

---

### METALCORE (4:30 target)

- Intro: 20–25s (sharp)
- Verse 1: 35–40s
- Pre-Chorus: 18–22s (building)
- Chorus: 32–37s (heavy)
- Verse 2: 35–40s
- Bridge (breakdown): 28–35s
- Guitar Breakdown: 25–30s
- Final Chorus: 35–40s
- Outro: 10–15s

**Total tolerance: ±8s from 270s meta**

---

### FOLK METAL (4:45 target)

- Intro: 25–30s (folk intro)
- Verse 1: 40–45s
- Pre-Chorus: 18–23s
- Chorus: 35–40s (celebratory)
- Verse 2: 40–45s
- Bridge (tribal): 30–38s
- Folk Break: 22–28s
- Final Chorus: 38–42s
- Outro: 14–18s

**Total tolerance: ±10s from 285s meta**

---

### NEOCLASSICAL METAL (5:00 target)

- Intro: 28–35s (classical build)
- Verse 1: 42–48s
- Pre-Chorus: 20–25s
- Chorus: 38–43s
- Verse 2: 42–48s
- Bridge (virtuoso): 32–40s (allow for shred)
- Guitar Solo (tech): 40–50s (technique-driven)
- Final Chorus: 42–48s
- Outro: 16–20s

**Total tolerance: ±12s from 300s meta**

---

## ✅ CHECKLIST BEFORE EACH GENERATION

- [ ] Subgénero detectado correctamente (usar tabla V6.1)
- [ ] Weirdness valor según tabla + ajuste escenario
- [ ] Style Influence valor según tabla (70–78% rango)
- [ ] Audio Influence OFF o configurado si hay upload
- [ ] Exclude Styles pasted (37 items completo)
- [ ] Melody Guide formato descriptivo (no literal)
- [ ] Vocal Tags alineados con subgénero
- [ ] Timing ranges (no segundos rígidos)
- [ ] DAC mandate en STYLES módulo
- [ ] Lyrics Mode: Manual (ON)
- [ ] Spanish accent LATINO confirmado (no España)

---

**LYRICA V6.1 - VOCAL TAGS & PARAMETERS**
**Status: COMPLETE AND READY FOR SUNO V5**
**February 10, 2026** ✅🎤
